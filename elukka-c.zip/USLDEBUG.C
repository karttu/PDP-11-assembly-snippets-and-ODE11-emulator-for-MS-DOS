 
#include "lb:[1,1]stdio.h"

#define USERFILE "DL0:[0,0]RSX11.SYS"


/* #define BUFSIZ 01000 */ /* Record size of RSX11.SYS in octal */
unsigned int BUFSIZ;

main(argc,argv)
int argc;
char **argv;
{
    char *malloc();
    FILE *fp;
    char group[4],member[4],first[13],last[15],dev[5];
    unsigned int i,count;
    char *buf;

    if(argc > 1)
     {
       BUFSIZ = atoi(*(argv+1));
     }
    else { BUFSIZ = 0200; }

    printf("I'm alive ! BUFSIZ = %u\n",BUFSIZ);

    if(!(buf = malloc(BUFSIZ+3)))
     {
       fprintf(stderr,
        "\n**Cannot allocate buffer !\n");
       exit(1);
     }

    if(!(fp = fopen(USERFILE,"r")))
     {
       fprintf(stderr,"\n**USL: unable to open file: %s\n",USERFILE);
       exit(1);
     }

    while(count = fread(buf,sizeof(char),BUFSIZ,fp))
     {
       printf("\ncount: %u\n",count);
       for(i = 0; i < count; i++)
        {
          printf("%4u %05o: %c %03o\n",i,i,
                  (isprint(buf[i]) ? buf[i] : '.'),((unsigned int)buf[i]));
        }
       if(!*buf) { continue; }   /* If empty record */
       strncpy(group,buf,3);     /* Get three octal digits of group */
       strncpy(member,buf+4,3);  /* Get three octal digits of member */
       strncpy(first,buf+12,12); /* Get 12-char first name */
       strncpy(last,buf+24,14);  /* Get 14-char last name */
       strncpy(dev,buf+46,4);    /* Get 4-char device-name */
/*
       printf("%s %s   %s:[%s,%s]\n",
          first,last,dev,group,member);
 */
     }

    fclose(fp);
}


