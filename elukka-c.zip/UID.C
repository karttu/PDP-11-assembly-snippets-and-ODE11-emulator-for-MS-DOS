 
#include "lb:[1,1]stdio.h"

main()
{
    printf("uid: %06o  gid: %06o\n",getuid(),getegid());
}

