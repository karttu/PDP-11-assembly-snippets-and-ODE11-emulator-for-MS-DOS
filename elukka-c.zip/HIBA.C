
#include "lb:[1,1]stdio.h"

#define MAXBUF 81
char buf[MAXBUF+2];


main(argc,argv)
int argc;
char **argv;
{
    int len;

petteri:
    printf((argc > 1) ? *(argv+1) : "Anna kalaa>");
    if(!fgets(buf,MAXBUF,stdin)) { exit(0); }
    len = strlen(buf)-1;
    if(buf[len] == '\n') { buf[len] = '\0'; } /* Delete the ending linefeed */
    putchar('\n');
    printf("%d\n",system(buf));
    goto petteri;
}


