
#include "lb:[1,1]stdio.h"
 
main(argc,argv)
int argc;
char **argv;
{
    if(!*++argv) { exit(0); }
    while(1)
     {
       fputs(*argv,stdout);
       if(!*++argv) { break; }
       putchar(' ');
     }
}

