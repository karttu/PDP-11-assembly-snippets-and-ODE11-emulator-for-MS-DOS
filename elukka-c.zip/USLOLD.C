

/* USL.C -- USer Listing command by Antti Karttunen, 1-APR-1991,
    lists all users and their UIC's and login times, etc.
    from RSX11.SYS, reading it "heuristically" (and in risky way)
    with fread & getc.
    Note that this program must be linked
    with /PRIV option to allow non-privileged users to read the
    account file RSX11.SYS. Works at least with RSX-11M.
    (with -PLUS requires some editing, I think).

    Note that if this program is buggy, then in worst case non-privileged
    users can accidentally see others' users passwords.

    Note that when RSX11.SYS (which is probably some kind of RMS-file)
    is read with fread and getc, then those fields whose values
    are zeros are not read at all ! So if there's zeros
    in time field then time printed can be incorrect, because
    this program can't certainly know which one, hours, minutes or seconds
    is lacking, so if one byte is lacking then it's assumed that
    time is HH:MM:00, if two bytes are lacking, then time is
    printed as HH:00:00 and if three bytes are lacking then
    it's (correctly) printed as 00:00:00
    Also program can't be always sure whether login count is one
    or two bytes, but it is "heuristically" assumed that if
    user is super user (group = 001) then he has been logged in more
    than 255 times and login count requires two bytes.

    This code is Public Domain.
 */

 
#include "lb:[1,1]stdio.h"

#define USERFILE  "DL0:[0,0]RSX11.SYS"
#define ERRORFILE "DL1:[1,4]ERRORS.USL"

/* Fixed (?) part of the records in RSX11.SYS, i.e UIC, pwd, last & 1st name */
#define BUFSIZ 38

char *getmonth();

main()
{
    FILE *fp,*errfp;
    register unsigned int c;
    char group[4],member[4],first[13],last[15],dev[5];
    register unsigned int login_count,i;
    unsigned int igroup;
    unsigned int day,month,year,hours,mins,secs;
    unsigned int surplus0,surplus1,surplus2,surplus3,surplus4;
    register char *p;
    char *errmsg;
    unsigned int *iaddr[12];
    char buf[BUFSIZ];

    /* There's no EQUALIZE-statement (like in Fortran) in C, so we
        must use hairy constructions like these: */
    iaddr[0] = &day;
    iaddr[1] = &month;
    iaddr[2] = &year;
    iaddr[3] = &hours;
    iaddr[4] = &mins;
    iaddr[5] = &secs;
    iaddr[6] = &surplus0;
    iaddr[7] = &surplus1;
    iaddr[8] = &surplus2;
    iaddr[9] = &surplus3;
    iaddr[10] = &surplus4;
    iaddr[11] = NULL;

    /* Set the ending zeros to buffers, because strncpy doesn't set it: */
    group[3] = member[3] = first[12] = last[14] = dev[3] = '\0';

    if(!(fp = fopen(USERFILE,"r")))
     {
       fprintf(stderr,"\n**USL: unable to open file: %s\n",USERFILE);
       exit(1);
     }
 
    fprintf(stderr,
/* 234567890123456789012345678901234567890123456789012345678901234567890 */
"User                        Home directory  Last login           # of logins\n"
           );

    while(1)
     {
       if(fread(buf,sizeof(char),BUFSIZ,fp) != BUFSIZ) { break; }

       /* Check that there is valid UIC as first six bytes: */
       for(p = buf; p < (buf+6);)
        { /* Check that *p is octal digit, and set p to null to flag
              that there was some non-octal-digit character: */
          if((*p++ & ~7) != '0') { p = NULL; break; }
        }
       if(!p)
        {
          errmsg = "\n**USL: Lost track of records, exiting !\n";
          goto ertzy; /* Nice code here, eh ? */
premature_eof:
          errmsg = "\n**USL: Premature EOF encountered, exiting !\n";
ertzy:
          fprintf(stderr,errmsg);
          /* Open error output to console log: */
          if(!(errfp = fopen(ERRORFILE,"w")))
           {
             fprintf(stderr,"\n**USL: cannot open %s !\n",ERRORFILE);
             exit(1);
           }
          fprintf(errfp,errmsg);
          /* Dump the buffer. To the console log because it can contain
              pieces of passwords or something: */
          for(i=0; i < BUFSIZ; i++)
           {
             fprintf(errfp,"%3u %06o: %c %03o %03u.\n",
                     i,i,(isprint(buf[i]) ? buf[i] : '.'),
                     ((unsigned int) buf[i]),((unsigned int) buf[i]));
           }
          for(i=0; iaddr[i]; i++)
           {
             fprintf(errfp,"*iaddr[%2u] %06o: %c %03o %03u.\n",
                 i,i,(isprint(*iaddr[i]) ? *iaddr[i] : '.'),
                  *iaddr[i],*iaddr[i]);
           }
          exit(1);
        }

       strncpy(group,buf,3);     /* Get three octal digits of group */
       strncpy(member,buf+3,3);  /* Get three octal digits of member */
       strncpy(last,buf+12,14);  /* Get 14-char last name */
       strncpy(first,buf+26,12); /* Get 12-char first name */

       igroup = login_count = 0;

       /* Clear the date, time, login count and device fields first: */
       for(i = 0; iaddr[i];) { *iaddr[i++] = 0; }

       sscanf(group,"%o",&igroup); /* Get binary value of group */

       /* Read date, time and login count (if there's any) until
          device-record (e.g. DL01) is encountered: */
       for(i = 0; ; i++)
        {
          if((c = getc(fp)) == EOF) { goto premature_eof; }
          if(!iaddr[i])
           {
             errmsg = "\n**USL: No device field encountered !\n";
             goto ertzy;
           }
          *iaddr[i] = c;
 /* Check if last three bytes are D (L/R/U/some other letter) and 0: */
          if((i > 1) && (*iaddr[i-2] == 'D')
               && (*iaddr[i] == '0'))
           { break; } /* Then stop reading */
        }

       dev[0] = *iaddr[i-2];
       dev[1] = *iaddr[i-1];
       if((c = getc(fp)) == EOF) { goto premature_eof; }
       dev[2] = c;
/*     dev[3] = '\0';  Unnecessary */

       /* Clear the locations, so that time doesn't get fucked up
           if there's one or more 0-fields in it: */
       *iaddr[i-2] = *iaddr[i-1] = *iaddr[i] = 0;

       if(i > 2) /* If user has been logged in at least once: */
        {
          login_count = *iaddr[i-3]; /* Take the low byte */
          *iaddr[i-3] = 0; /* And then clear the location */
/* If 8 bytes information between first name and DL0 or it's super user
   (group = 1, i.e. SULKU or SYSMGR), then there's two bytes
   for login_count instead of one: */
          if((i == 10) || ((i > 3) && (igroup == 1)))
           { /* So compute the high byte also: */
             login_count = ((login_count << 8) + *iaddr[i-4]);
             *iaddr[i-4] = 0; /* And clear the location */
           }
        }

       /* Read the Radix-50 word for DCL (MCR or DCL) away: */
       if(getc(fp) == EOF) { goto premature_eof; }
       if(getc(fp) == EOF) { goto premature_eof; }

/* Read surplu(s)-bytes from the end of the record, if there's any:
   (e.g. if slave-terminal)
 */
       while(1)
        {
          if((c = getc(fp)) == EOF) { break; }
          /* If it's first octal digit of next UIC, then push it back
             to io stream and break from this loop: */
          if((c & ~7) == '0') { ungetc(c,fp); break; }
        }

       /* If there's at least one zero in time (but not all !)
         (but date is not zero, i.e. user has been logged in at least once)
         then mark time as dubious with question mark: */
       if(month && (!hours || !mins || !secs) && (hours || mins || secs))
        { c = '?'; }
       else { c = ' '; }

       /* Do some "heuristics" here, that is, if there's zero fields
          in time, then check that hours are not above 23, if they
          are then move them to minutes, and minutes to seconds: */
       if(!secs && (hours > 23)) /* Hours can be 00-23 */
        { secs = mins; mins = hours; hours = 0; }

       printf("%s %s %s:[%s,%s]   %02u-%s-%02u  %02u:%02u:%02u%c %u\n",
          first,last,dev,group,member,
          day,getmonth(month),year,hours,mins,secs,c,login_count);
 
     }

    fclose(fp);
}


static char *months[]=
 {
   "000", "JAN", "FEB", "MAR", "APR", "MAY", "JUN",
          "JUL", "AUG", "SEP", "OCT", "NOV", "DEC", NULL
 };


char *getmonth(month)
unsigned int month;
{
    if(month <= 12) { return(months[month]); }
    else { return("???"); }
}


