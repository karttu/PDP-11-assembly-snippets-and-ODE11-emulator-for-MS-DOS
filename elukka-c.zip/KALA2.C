
#include "lb:[1,1]stdio.h"

#define MAXBUF 79
char buf[MAXBUF+2];

char *r50toa();

main()
{
    int x;
    char s[MAXBUF+2];

    strcpy(s,"nakkimakkara");

    while(fgets(buf,MAXBUF,stdin))
     {
       sscanf(buf,"%o",&x);
       printf("x=%06o\n",x);
;      r50toa(s,x);
       printf("%s\n",r50toa(x));
     }
}

