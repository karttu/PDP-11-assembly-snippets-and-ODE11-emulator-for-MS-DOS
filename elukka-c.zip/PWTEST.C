
#include "lb:[1,1]stdio.h"
#include "lb:[1,1]pwd.h"

main(argc,argv)
int argc;
char **argv;
{
    struct passwd *getpwent();
    struct passwd *p;

    while(p = getpwent())
     {
       printf("pw_name: %s  pw_passwd: %s  pw_uid: %06o  pw_gid: %06o\n",
                 p->pw_name,p->pw_passwd,p->pw_uid,p->pw_gid);
       printf("pw_age: %s   pw_comment: %s/%u/%lu\n",
                 p->pw_age,p->pw_comment,strlen(p->pw_comment),p->pw_comment);
       printf("pw_gecos: %s  pw_dir: %s  pw_shell: %s\n",
                 p->pw_gecos,p->pw_dir,p->pw_shell);
       printf("\n");
     }
}

