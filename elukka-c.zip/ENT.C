
#include "lb:[1,1]stdio.h"
#include "lb:[1,1]pwd.h"

#define SYSUSR "SYSMGR"
#define ERTZU 3

#define MAXBUF 78

main(argc,argv)
int argc;
char **argv;
{
    struct passwd *getpwild();
    struct passwd *p;
    unsigned gid;
    char buf[MAXBUF];

    p = getpwild("."); /* Get entry for this user */
    gid = getgid();
    if(!p) /* If no entry found */
     { /* Then check if system user, and dig the entry of SYSMGR: */
       if(gid == 1) { setpwent(); p = getpwild(SYSUSR); }
       if(!p)
        { fprintf(stderr,
"\n**Sorry, can't find name for your UIC, please go to your home directory.\n"
                );
          exit(ERTZU);
        }
     }

    endpwent(); /* Close user file */

/*
    Give firstname, lastname & home directory as first three arguments to ENX:
 */
    sprintf(buf,"ENX %s %s",p->pw_gecos,p->pw_dir);
 /* Concatenate additional args to the command line, if there's any: */
    while(*++argv) { strcat(buf," "); strcat(buf,*argv); }
    /* If first char of last arg is @ then show buffer (debugging): */
    if(**--argv == '@') { fprintf(stderr,"\nbuf: %s\n",buf); }
    system(buf); /* Execute command in MCR */
}

