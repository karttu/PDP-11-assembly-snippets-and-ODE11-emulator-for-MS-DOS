
/* Query.C -- Queries some information from users using guest account,
    and sends it to console log.
   By Antti Karttunen, 1-APR-1991. PD.
 */

#include "lb:[1,1]stdio.h"

FILE *console,*title_fp;

#define TITLEFILE "TITLE.TXT"

#define MAXBUF 78
char buf[MAXBUF+3];

#define N_QUESTS 7

static char *quests[N_QUESTS]=
 {
   "destination",
   "obsession",
   "odour",
   "personal perversion",
   "size",
   "vice",
   "vocation"
 };


main(argc,argv)
int argc;
char **argv;
{
    long time(); /* ago... */
    register unsigned int r;
    register char *s;
/*  char buf[MAXBUF+3]; */

    if(!(console = fopen("CO0:","a")))
     {
       fprintf(stderr,
                "\n**QUERY failed, cannot open CO0: !\n");
       exit(1);
     }

loop0:
    printf(
"\nPlease answer to the following questions, thank you! (max. %u chars/line)\n"
          ,MAXBUF);
    note();

loop1:
    printf("Your name: \n>>");
    *buf = '\0'; fgets(buf,MAXBUF,stdin);
    if(emptyp(buf)) { goto loop1; }
    if(previous(buf)) { goto loop0; }
    fprintf(console,"NAME:  %s",buf);
    fflush(console);

/* Write a name of the user to titlefile, so if (s)he enters a message
    then it will appear as written by GUEST GUEST (Name Given)
 */
    if(title_fp = fopen(TITLEFILE,"w"))
     {
       fprintf(title_fp,"%s\n",buf);
       fclose(title_fp);
     }

loop2:
    printf("Calling from (city, continent, etc.):\n>>");
    *buf = '\0'; fgets(buf,MAXBUF,stdin);
    if(emptyp(buf)) { note(); goto loop2; }
    if(previous(buf)) { goto loop1; }
    fprintf(console,"FROM:  %s",buf);
    fflush(console);

loop3:
    printf("Where do you have heard/read about this telephone-number ?\n>>");
    *buf = '\0'; fgets(buf,MAXBUF,stdin);
    if(emptyp(buf)) { note(); goto loop3; }
    if(previous(buf)) { goto loop2; }
    fprintf(console,"HEARD: %s",buf);
    fflush(console);

loop4:
    printf("Your e-mail address or BBS where you can be reached out:\n>>");
    *buf = '\0'; fgets(buf,MAXBUF,stdin);
    if(emptyp(buf)) { note(); goto loop4; }
    if(previous(buf)) { goto loop3; }
    fprintf(console,"EADDR: %s",buf);
    fflush(console);

loop5:
    printf(
      "Computer(s) or terminal(s) you are using/have experience with:\n>>");
    *buf = '\0'; fgets(buf,MAXBUF,stdin);
    if(emptyp(buf)) { note(); goto loop5; }
    if(previous(buf)) { goto loop4; }
    fprintf(console,"COMP:  %s",buf);
    fflush(console);

loop6:
    r = (unsigned int) time(NULL);

    s = quests[(r & 077777) % ((unsigned int) N_QUESTS)];
    printf("Your %s:\n>>",s);
    *buf = '\0'; fgets(buf,MAXBUF,stdin);
    if(emptyp(buf)) { note(); goto loop6; }
    if(previous(buf)) { goto loop5; }
    fprintf(console,"%s: %s",s,buf);
    fflush(console);

    printf("\nThat's all. To supply more information use REQUEST command.\n");
    printf("Happy hacking.\n");

    fclose(console);
}

note()
{
    printf(
"Use - to go to the previous question, if you answered it incorrectly,\n"
          );
    printf("or if you want to enter more than one line.\n");
}

int emptyp(s)
register char *s;
{
     return((*s == '\n') || !*s);
}

int previous(s) /* If s is "-" */
register char *s;
{
     return((*s == '-') && (!*(s+1) || (*(s+1) == '\n')));
}



