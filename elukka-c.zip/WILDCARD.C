

/*
   Written by Antti Karttunen once upon a time.
   This code is public domain.
 */



/* #include "mydefs.h" */ /* For abs and min */

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE  1
#endif

/*
    Default group chars changed from < and > to ( and )
    for RSX-version, because angle brackets are used for
    redirection and [ and ] for UICs
 */


static char GROUP_BEG_CHAR = '(';
static char GRUOP_END_CHAR = ')';


/*
   Pattern can contain following characters:

    ?   Matches one character which can be anything.
    *   Matches zero or more of any characters.

    (   Start of the "group-expression", which contains some chars,
         and must end in )
        If first char after ( is ^ then its semantics are negated.
        If first char after ( or ^ is ) then it's not understood yet as end
         delimiter.
    Examples:
        (abc)          Matches any of the letters a, b and c.
        (^0123456789)  Matches anything, except digits.
        ())            Matches )
        (^))           Matches anything except )

    @   Matches character last matched to ? or group-expression.
         For example ?*@ matches to all strings which begin with same
         character they end.
        However, if pattern starts with @ then it sets the group
         start & end characters, e.g. pattern: @{tuu<ba{123}pasuuna
         matches to anything which begins tuu<ba then after that is
         1, 2 or 3 and after that pasuuna.

     Any other characters match just to themselves.

   Note that unix-like [0-9] (corresponding to (0123456789)) is not
   implemented yet.
*/



/* Returns 1 if match, 0 if not */
int w_match(pattern,string)
char *pattern,*string;
{
    int wild_card_aux();

    if(*pattern == '@') /* Set group-expression delimiter characters. */
     { /* Set GROUP_BEG_CHAR to be char after @, and if it is not '\0' */
       if(GROUP_BEG_CHAR = *++pattern) { pattern++; } /* then skip it also. */
       GRUOP_END_CHAR = get_end_delimiter(GROUP_BEG_CHAR);
     }
    return(wild_card_aux(pattern,string,'\0'));
}


int wild_card_aux(pattern,string,last_matched)
register char *pattern,*string;
register char last_matched;
{
    int wild_card_aux();
    char *_pattern,*_string,_last_matched; /* Memory versions for &-operator */

loop:

    if(!*pattern && !*string) return(TRUE); /* if BOTH are in the end */
    /* Asterisk may match emptiness at the end of string: */
    if((*pattern == '*') && !*string)
     { pattern++; goto loop; }
    if(!*pattern || !*string) return(FALSE); /* If only OTHER is in the end */
    if(*pattern == GROUP_BEG_CHAR)
     {
       if(group_match(&_pattern,&_string,&_last_matched))
        { /* Move memory variables to register variables: */
          pattern = _pattern; string = _string; last_matched = _last_matched;
          goto loop;
        }
       else { return(FALSE); }
     }
    if(*pattern == '?') /* Question-mark in pattern ? */
     { pattern++; last_matched = *string++; goto loop; }
    if((*pattern == '@') && last_matched)
     {
       if(*string == last_matched) { goto silava; }
       else { goto sulava; }
     }
    if(*pattern == '*') /* It (*) matches several chars: */
     {
       return(wild_card_aux(pattern,string+1,last_matched)
               || /* Matches one character: (not really necessary)
              wild_card_aux(pattern+1,string+1,last_matched)
               ||  */             /* Matches 0 characters: */
              wild_card_aux(pattern+1,string,last_matched));
     }
    else sulava: if(*pattern == *string) /* Same characters ? */
     { silava: pattern++; string++; goto loop; }
    else { return(FALSE); }
}


int group_match(pat_adr,str_adr,lmc_adr)
/* unsigned */ char **pat_adr,**str_adr;
/* unsigned */ char *lmc_adr; /* Address of the last matched character */
{
        /* unsigned */ char *index();
        register /* unsigned */ char *pat;
        register /* unsigned */ char c,positive_flag;

        /* Take current char. from string, and advance string by one: */
        c = *(*str_adr)++;
        pat = (*pat_adr)+1; /* Skip group beginning char */

/* positive_flag is on if there is no negation-sign (^) in the beginning: */
        if(*pat == '^') { positive_flag = 0; pat++; }
        else { positive_flag = 1; }

        while(*pat)
         {
           if(*pat == c) /* If found c from the pattern. */
            { /* If group ending char not found, then return false: */
              if(!(pat = index((pat+1),GRUOP_END_CHAR))) { return(FALSE); }
              else
               {
                 /* Set pattern to point one after group_end_char: */
nakki:           *pat_adr = (pat+1);
                 if(positive_flag) /* Set last_matched char. */
                  { *lmc_adr = c; }
                 return(positive_flag);
               }
            }
           if(*++pat == GRUOP_END_CHAR)
            {
/* If there was negation-sign (^) in the beginning, meaning that
    positive_flag was 0, then set it to 1, and jump to nakki
    to return true result. Because we are here it means that
    c doesn't match to group, so if ^ in the beginning, then
    return true.
 */           /* He he hee hee hee, some sick code again: */
              positive_flag = !positive_flag;
              goto nakki;
            }
         }

        return(FALSE); /* If no group_ending_character */
}

int get_end_delimiter(c)
char c;
{
    return((c == '(') ? ')' : 'c'+2);
}

