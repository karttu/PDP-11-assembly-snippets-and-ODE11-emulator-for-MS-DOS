
/* Some development for simple program to enter the messages
    to the message directory.

   First start EDT editor to write the message into tmp-directory,
    then ask the conference and name where/who to send it to.
   Write the header info to the start of CONFNAME.MSG;NEWEST-VERSION
    and concatenate the temporary file after that.
   And that's it.

   By A. Karttunen May 4 1991 onward.
 */


#include "lb:[1,1]stdio.h"

/* #define DEFCONF   "general"      */ /* Default conference name */
/* #define TMPDIR    "DL1:[177,30]" */ /* Temporary directory (not used ?) */
#define TMPFILE   "TMP.MSG"
#define MSGDIR    "DL1:[30,1]"    /* Massage directory */
#define TITLEFILE "TITLE.TXT"
/* #define SYSUSR    "SYSMGR" */
#define PRIVGROUP  0301           /* Privileged Insider Group */
#define ilmo       stderr
#define SUC        1
#define ERTZU      3
#define MAXBUF     78


char *get_date();
char *maketempname();
char *myfgets();
char *convert_string();
int toupper();

FILE *fopen();
FILE *tmp_in,*test_fp,*msg_out;

/* #define msgnum 666 */
/* #define homedir p->pw_dir */

#define firstname argv[1]
#define lastname  argv[2]
#define homedir   argv[3]

char buf3[MAXBUF+2];

main(argc,argv)
int argc;
char **argv;
{
    unsigned gid; /* ,uid,msgnum,replynum; */
    char *confname,*reply_to,*replyconf;
    char buf1[MAXBUF+2],buf2[MAXBUF+2];
    char to[MAXBUF+2],subj[MAXBUF+2+6],title[MAXBUF+2];

    confname = argv[4];
    reply_to = replyconf = NULL;

    if(argc < 5)
     {
       fprintf(stderr,"\nUse ENT for entering messages!\n");
       exit(ERTZU);
     }

    if(argc > 5)
     {
       reply_to = *(argv+5);
     }

    if(argc > 6)
     {
       replyconf = *(argv+6);
     }
    else { replyconf = confname; }


    /* p = getpwild("."); */ /* Get the entry for this user */
    
    gid = getgid();

/*  system("DCL SHOW TERM"); */ /* Just debugging (show privs) */

    maketempname(homedir,buf1);

    strcpy(buf2,"EDT ");
    strcat(buf2,buf1);

    fprintf(ilmo,
"\nEnter message:  I - Write in line mode, C - Write in screen mode (VT102).\n");
    fprintf(ilmo,
"^W - Refresh screen, ^Z - Back to command prompt, 0:END - List the message.\n"
           );
    fprintf(ilmo,
"T n:m - List lines n-m, EX - Save the msg, QUIT - Abort, H - Get help.\n");

    system(buf2);

    if(!(tmp_in = fopen(buf1,"r")))
     {
       fprintf(stderr,"\n**No file written. Aborted.\n",
                 buf1);
       exit(ERTZU);
     }

    /* Read the title line from title file: */
    strcpy(buf2,homedir);
    strcat(buf2,TITLEFILE);
    if(!(test_fp = fopen(buf2,"r")))
     {
       *title = '\0'; /* If no titlefile, then use empty title */
     }
    else
     {
       myfgets(title,MAXBUF,test_fp);
       fclose(test_fp);
     }

/*
    if(confname) { strcpy(buf1,confname); }
    else
     {
       fprintf(ilmo,"Conference (enter for %s):",DEFCONF);
       myfgets(buf1,MAXBUF,stdin);
       if(!*buf1) { strcpy(buf1,DEFCONF); }
     }
 */


luuppi:
    convert_string(confname,toupper);
    strcpy(buf2,MSGDIR);
    strcat(buf2,confname);
    strcat(buf2,".MSG");

    if(!(test_fp = fopen(buf2,"r")))
     {
       fprintf(stderr,
         "**No conference %s !\n",confname);
nauta:
       if(gid != PRIVGROUP) /* for masses */
        {
          fprintf(stderr,
"Enter conference name again, or quit the message with Q: ");
        }
       else /* insiders can found new conferences: */
        {
          fprintf(stderr,
"If you want to create new conf. with that name then enter NEW to create it,\n"
              );
         fprintf(stderr,
"or correct name of the conference, Q to abort: ");
        }
       /* Use buf3 as temporary buffer to read answer in: */
       myfgets(buf3,MAXBUF,stdin);
       convert_string(buf3,toupper);
       if(!*buf3) { goto nauta; } /* If blank line entered */
       if(!strcmp(buf3,"Q")) { goto abort1; }
       if(strcmp(buf3,"NEW")) { confname = buf3; goto luuppi; } /* Buggy ? */
     }
    fclose(test_fp);

    if(reply_to)
     {
       if(!dig_refer(reply_to,replyconf,to,subj)) { goto abort1; }
       fprintf(stderr,
"Reply to %s, subj: %s\n",
           to,subj);
       fprintf(stderr,
"Enter new subject, or enter to keep it same: ");
       myfgets(buf1,MAXBUF,stdin);
       if(*buf1) { strcpy(subj,buf1); }
       sprintf(to,"%s  (-> %s:%s)",to,replyconf,reply_to);
     }
    else
     {
       fprintf(ilmo,"To (enter for ALL): ");
       myfgets(to,MAXBUF,stdin);
       if(!*to) { strcpy(to,"ALL"); }
       fprintf(ilmo,"Subject: ");
       myfgets(subj,MAXBUF,stdin);
     }

    if(!(msg_out = fopen(buf2,"w")))
     {
       fprintf(stderr,
"**Cannot open file %s for output !\n",buf2);
       goto abort1;
     }

    convert_string(confname,toupper); /* Convert conf name to uppercase */
    convert_string(firstname,toupper); /* And the name of */
    convert_string(lastname,toupper); /* the sender */
    convert_string(to,toupper);   /* And receiver name too */

/* Write the message header: */
    fprintf(msg_out,"%s  %s\n",
              confname,get_date());
    fprintf(msg_out,"From: %s %s (%s)\n",firstname,lastname,title);
    fprintf(msg_out,"To:   %s\n",to);
    fprintf(msg_out,"Subj: %s\n\n",subj);

/* Copy the stuff itself from temporary file to the message file: */
    copystream(msg_out,tmp_in);
    fclose(msg_out);
    fclose(tmp_in);
    del_tmpfile(homedir); /* Delete the temporary file */
    exit(SUC);

abort1:

    fprintf(stderr,
"**Aborted. Message left to TMP.MSG in your home directory\n");

/*
    fprintf(stderr,
"Enter name of file where to save stuff (default NOTSENT.MSG),\n");
    fprintf(stderr,
"or enter NL: to discard file: ");
abort2:
    myfgets(buf2,MAXBUF,stdin);
    strcpy(buf1,homedir);
    if(!*buf2)
     {
       strcat(buf1,"NOTSENT.MSG");
     }
    else
     {
       strcat(buf1,buf2);
     }
    if(!(test_fp = fopen(buf1,"w")))
     {
       fprintf(stderr,
"**Cannot open %s either, enter better name !\n");
       goto abort2;
     }
    else { fprintf(stderr,"Message saved to %s !\n",buf1); }
    copystream(test_fp,tmp_in);
    fclose(test_fp);
    fclose(tmp_in);
    del_tmpfile(homedir);
 */
    exit(ERTZU);
}

del_tmpfile(dire)
char *dire;
{
    char buf[MAXBUF];

    sprintf(buf,"PIP %s%s;*/DE",dire,TMPFILE);
    system(buf);
}

copystream(to,from)
register FILE *to,*from;
{
    register int c;

    while((c = getc(from)) != EOF) { putc(c,to); }
}


char *maketempname(directory,buf1)
char *directory,*buf1;
{
    strcpy(buf1,directory);
    strcat(buf1,"tmp.msg");
    return(buf1);
}


/* This digs the receiver name (to) and default subject (subj)
    from the referenced message replyconf.MSG;reply_to
    (if there's any).
   Buffers to and subj are used first for all kind of buffering,
    just to save the stack space. (Not very clearly...)
 */
int dig_refer(reply_to,replyconf,to,subj)
register char *reply_to,*replyconf,*to,*subj;
{
/*  int octnum; */
    FILE *ref_in;

/* This is not necessary...
    if(!all_charsp(reply_to,isoctdigitp))
     { goto ertzu; }
 */
/*
    sscanf(reply_to,"%o",&octnum);
 */
    sprintf(to,"%s%s.MSG;%s",MSGDIR,replyconf,reply_to);
    if(!(ref_in = fopen(to,"r"))) { goto ertzu; } /* Try to open */
    if(!myfgets(subj,MAXBUF+6,ref_in)) { goto ertzu; } /* First line */
    if(!myfgets(subj,MAXBUF+6,ref_in)) { goto ertzu; } /* Second line */
    subj[5] = '\0';
    if(strcmp(subj,"From:")) { goto ertzu; } /* Check the validity.. */
    strcpy(to,subj+6); /* And get receiver name */
    if(!myfgets(subj,MAXBUF+6,ref_in)) { goto ertzu; } /* Third line */
    if(!myfgets(subj,MAXBUF+6,ref_in)) { goto ertzu; } /* Fourth line */
    subj[5] = '\0';
    if(strcmp(subj,"Subj:")) { goto ertzu; } /* Check the validity... */
    strcpy(subj,subj+6); /* And get the old subject */

    fclose(ref_in);
    return(1 /* octnum */);

ertzu:
    fprintf(stderr,
"\n**Cannot reply to %s.MSG;%s ! File nonexistent or invalid?\n",
             replyconf,reply_to);
    fprintf(stderr,"to: %s/%u  subj: %s/%u\n",
              to,strlen(to),subj,strlen(subj));
    if(ref_in) { fclose(ref_in); }
    return(0);
}


char *myfgets(buf,maxsize,fp)
register char *buf;
register int maxsize;
FILE *fp;
{
    char *fgets();

    if(!fgets(buf,(maxsize-1),fp)) { return(NULL); }

    if(maxsize=strlen(buf)) { buf[maxsize-1] = '\0'; }
    return(buf);
}


char *get_date()
{
    register char *s;
    long aika;
    long time();
    char *ctime();
    char buf[25];

    time(&aika);
    s = ctime(&aika);

    /* And then convert from Unix format to "VMS-format": */

/*              012345678901234567890123 */
/* Old format:  Thu Jun 27 20:06:39 1991 */
/* New format:  Thu 27-JUN-91 20:06:39   */

    s[24] = '\0'; /* Take newline away */
    strcpy(buf,s);
    buf[7]  = '\0'; /* Cut after month */
    convert_string(buf+4,toupper); /* And convert month to uppercase */
    buf[19] = '\0'; /* Cut after time */
    sprintf(s+4,"%c%c-%s-%s %s",
             buf[8],buf[9],buf+4,buf+22,buf+11);

    return(s);
}


typedef int (*PFI)();
#define UINT unsigned

/* Converts every character of s with convfun, for example:
    convert_string(buf,toupper);
    changes every alphabetic character in buf to upper case.
 */
char *convert_string(s,convfun)
register char *s;
PFI convfun;
{
        char *orig_s;

        orig_s = s;
        while(*s) { *s = ((*convfun)(*s)); s++; }
        return(orig_s);
}

