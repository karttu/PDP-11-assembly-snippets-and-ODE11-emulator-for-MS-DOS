
/* Converts every character of s with convfun, for example:
    convert_string(buf,toupper);
    changes every alphabetic character in buf to upper case.
 */
char *convert_string(s,convfun)
register char *s;
PFI convfun;
{
        char *orig_s;

        orig_s = s;
        while(*s) { *s = ((*convfun)(*s)); s++; }
        return(orig_s);
}

