
/*
    Getpwent.c - GETPWENT routines for PDP-11 RSX-11M
     coded by A. Karttunen -91


    Abridged version of getpwent.c so that it doesn't get too big
    and is willing to work.

    Note that if this code is buggy, then in worst case non-privileged
    users can accidentally see others' users passwords.
    (So it's good idea not to allow digits in first characters of
     password, so it's easier for this code to distinguish what is
     UIC and what is password).

    Note that when RSX11.SYS (which is probably some kind of RMS-file)
    is read with fread and getc, then those fields whose values
    are zeros are not read at all ! So if there's zeros
    in time field then time printed can be incorrect, because
    this program can't certainly know which one, hours, minutes or seconds
    is lacking, so if one byte is lacking then it's assumed that
    time is HH:MM:00, if two bytes are lacking, then time is
    printed as HH:00:00 and if three bytes are lacking then
    it's (correctly) printed as 00:00:00
    Also program can't be always sure whether login count is one
    or two bytes, but it is "heuristically" assumed that if
    user is super user (group = 001) then he has been logged in more
    than 255 times and login count requires two bytes.

    This code is Public Domain.
 */

 
#include "lb:[1,1]stdio.h"
#include "lb:[1,1]pwd.h"

typedef int (*PFI)();

char *getmonth();
char *cut_blankos();
char *convert_string();
char *normalize_pattern();
char *index(),*rindex();


struct passwd *getpwent(),*getpwuid(),*getpwnam(),*getpwild();


#define _progname "getpwent" /* This is used in error messages */

#define USERFILE  "DL0:[0,0]RSX11.SYS"
#define ERRORFILE "DL1:[1,4]ERRORS.PWD"

/* (Max.) Length of some fields in RSX11.SYS: */

#define L_FNAME    12
#define L_LNAME    14
#define L_PASSWD   6
#define L_AGE      19
#define L_COMMENT  5
#define L_DIR      13
#define L_GECOS    (L_FNAME+1+L_LNAME)
#define L_SHELL    3

#define L_BUF      11

#define L_PAT      50

#define I_GID      5 /* Indexes to GID */
#define I_MEM      9 /* and MEM in _dir */

#define I_DAY      0
#define I_MONTH    1
#define I_YEAR     2
#define I_HOURS    3
#define I_MINS     4
#define I_SECS     5

static struct passwd _p;
static FILE *_pw_file=NULL;

static char _name[L_LNAME+1]; /* Last name */
static char _passwd[L_PASSWD+1]; /* Six-char. password (uncrypted !) */
static char _age[L_AGE+1]; /* Use this for last login information */
static char _comment[L_COMMENT+1]; /* Use this for login count information */
static char _gecos[L_GECOS+1]; /* First & Last name (separated by space) */
static char _dir[L_DIR+1];   /* DL?:[ggg,mmm] */
static char _shell[L_SHELL+1];  /* MCR or DCL */

/* (Temporary) buffer for last login date and time & login count & device
    as they are read from userfile: */
static char _buf[L_BUF+1];

/* pattern stuff for normalize_pattern and getpwild: */
static char *_pattern=NULL,*_look_for=NULL;
static char _patbuf[L_PAT+5];

#define day     _buf[I_DAY]
#define month   _buf[I_MONTH]
#define year    _buf[I_YEAR]
#define hours   _buf[I_HOURS]
#define mins    _buf[I_MINS]
#define secs    _buf[I_SECS]


init()
{
    if(!(_pw_file = fopen(USERFILE,"r")))
     {
       fprintf(stderr,
"\n**%s: can't open file %s !\n",_progname,USERFILE);
       exit(1);
     }

/* Initialize fields to point to the static string buffers: */ 
    _p.pw_name     = _name;
    _p.pw_passwd   = _passwd;
    _p.pw_uid      = 0;
    _p.pw_gid      = 0;
    _p.pw_age      = _age;
    _p.pw_comment  = _comment;
    _p.pw_gecos    = _gecos;
    _p.pw_dir      = _dir;
    _p.pw_shell    = _shell;

/* Set ending-zeros (maybe not necessary in all cases) */
    _name[L_LNAME]      = '\0';
    _passwd[L_PASSWD]   = '\0';
/*  _age[L_AGE]         = '\0';
    _comment[L_COMMENT] = '\0'; */
    _gecos[L_GECOS]     = '\0';
/*  _dir[L_DIR]         = '\0'; */
    _shell[L_SHELL]     = '\0';

/*               0123456789ABCD */
    strcpy(_dir,"DL?:[ggg,mmm]"); /* Copy the directory template to _dir */
}


/* void */ setpwent()
{
    if(_pw_file) { endpwent(); }
    init();
}

/* void */ endpwent()
{
    if(_pw_file) { fclose(_pw_file); }
    _pw_file = NULL;
    _pattern = _look_for = NULL;
}

struct passwd *getpwuid(uid)
unsigned int uid;
{
    while(getpwent())
     {
       if(_p.pw_uid == uid) { return(&_p); }
     }

    return(NULL); /* Return NULL if nothing found */
}


struct passwd *getpwnam(name)
char *name;
{
    return(getpwild(name));
}



struct passwd *getpwild(pattern)
register char *pattern;
{

    if(!*(pattern+1)) /* If pattern is one character long */
     {
       if(*pattern == '*') { return(getpwent()); } /* Matches everything */
       if(*pattern == '.') /* Dot matches to current user name */
        { return(getpwuid(getuid())); }
     }

    if(!_look_for) { _look_for = normalize_pattern(pattern); }

    while(getpwent())
     {
       if(w_match(_pattern,_look_for)) { return(&_p); }
     }

    return(NULL);
}


char *normalize_pattern(pattern)
register char *pattern;
{
    int toupper();
    char *norm_aux();
    register char *p,*q;

    p = index(pattern,',');
    if((*pattern == '[') || (isdigit(*pattern)) || p)
     { /* It's UIC pattern */
       if(p) { *p = '\0'; } /* Cut string temporarily from comma */
       q = norm_aux(_patbuf,pattern); /* Normalize group-part of UIC */
       *q++ = ','; /* Put the comma between */
       q = norm_aux(q,(p ? (p+1) : p)); /* Normalize memberpart of UIC */
       *q++ = ']'; /* Set the ending bracket */
       *q   = '\0'; /* And EOS */
       if(p) { *p = ','; } /* Restore the comma to the original pattern */

       _pattern = _patbuf;

       /* No need to convert UIC patterns to upper case */

       /* Return the UIC part of dir, just after [ */
       return(_dir+I_GID);
     }

    _patbuf[L_PAT] = '\0';
    strncpy(_patbuf,pattern,L_PAT);
    _pattern = _patbuf;
    convert_string(_pattern,toupper);

    if(p = rindex(_pattern,'_'))
     { /* If one or more _'s in pattern then match it against gecos,
           i.e. whole name, not just last name */
       substitute(' ','_',_pattern); /* Convert _'s to blankos */
       if(!*(p+1)) /* If last character is blanko (was _) then append * */
        { strcat(_pattern,"*"); }
       return(_gecos); /* Match against gecos, i.e. whole name */
     }
    else { return(_name); } /* Match only against last name */
}

char *norm_aux(result,source)
register char *result,*source;
{
     register unsigned int len;

     if(!source) { goto togo; }

     if(*source == '[') { source++; } /* Skip [ in beginning if there's any */

     switch(*source)
      { /* If that part of UIC is empty, then replace it with asterisk: */
        case ',': case ']': case '\0':
togo:    { *result = '*'; return(result+1); }
      }

     len = strlen(source);
     if((len >= 3) || index(source,'*'))
      {
        result[L_PAT] = '\0';
        strncpy(result,source,L_PAT);
        return(result+len);
      }
     else /* Fill the leading zeros */
      {
        while(len++ < 3) { *result++ = '0'; }
        strcpy(result,source);
        return(result+len);
      }
}


struct passwd *getpwent()
{
    register unsigned int c;
    register unsigned int login_count,i;
    unsigned int igroup;

/* If password file is not yet opened then open it (i.e. this is first call) */
    if(!_pw_file) { init(); }

       if(fread((_dir+I_GID),sizeof(char),3,_pw_file) != 3)
        { endpwent(); return(NULL); } /* No more entries in userfile */
       if(fread((_dir+I_MEM),sizeof(char),3,_pw_file) != 3)
        { eof_ertzu(); }
       if(fread(_passwd,sizeof(char),L_PASSWD,_pw_file) != L_PASSWD)
        { eof_ertzu(); }
       if(fread(_name,sizeof(char),L_LNAME,_pw_file) != L_LNAME)
        { eof_ertzu(); }
       if(fread(_gecos,sizeof(char),L_FNAME,_pw_file) != L_FNAME)
        { eof_ertzu(); }

       /* Check that there is valid UIC as first six bytes: */
       for(i = I_GID; i < (I_MEM+3);)
        { /* Check that char is octal digit, and set i to zero to flag
              that there was some non-octal-digit character: */
          if((_dir[i++] & ~7) != '0') { i = 0; break; }
          if(i == (I_MEM-1)) { i++; } /* Skip the comma between */
        }
       if(!i) { ertzu("\n**%s: Lost track of records, exiting !\n"); }
       igroup = login_count = 0;

       /* Clear the date, time, login count and device fields first: */
       clear_buf(_buf,L_BUF);

       sscanf((_dir+I_GID),"%o",&igroup); /* Get binary value of group */
       sscanf((_dir+I_MEM),"%o",&_p.pw_uid); /* Get binary value of member */

       _p.pw_gid  = igroup;
       _p.pw_uid += (igroup << 8); /* whole UIC to _p.uid */

       /* Read date, time and login count (if there's any) until
          device-record (e.g. DL01) is encountered: */
       for(i = 0; ; i++)
        {
          if((c = getc(_pw_file)) == EOF) { eof_ertzu(); }
          if(i > L_BUF)
           {
             ertzu("\n**%s: No device field encountered !\n");
           }
          _buf[i] = c;
 /* Check if last three bytes are D (L/R/U/some other letter) and 0: */
          if((i > 1) && (_buf[i-2] == 'D')
               && (c == '0'))
           { break; } /* Then stop reading */
        }

       /* Put device (DL0 or DL1 or alike) to first three chars of _dir: */
       _dir[0] = _buf[i-2];
       _dir[1] = _buf[i-1];
       if((c = getc(_pw_file)) == EOF) { eof_ertzu(); }
       _dir[2] = c;

/* ===========================================================================
      Login time & count section commented out of abridged version !


       (* Clear the locations, so that time doesn't get fucked up
           if there's one or more 0-fields in it: *)
       clear_buf((_buf+(i-2)),3); (* _buf[i-2] to _buf[i] *)

       if(i > 2) (* If user has been logged in at least once: *)
        {
          login_count = ((unsigned int) _buf[i-3]); (* Take the low byte *)
          _buf[i-3] = '\0'; (* And then clear the location *)
(* If 8 bytes information between first name and DL0 or it's super user
   (group = 1, i.e. SULKU or SYSMGR), then there's two bytes
   for login_count instead of one: *)
          if((i == 10) || ((i > 3) && (igroup == 1)))
           { (* So compute the high byte also: *)
             login_count = ((login_count << 8) + ((unsigned int) _buf[i-4]));
             _buf[i-4] = '\0'; (* And clear the location *)
           }
        }

       (* Here was two lines of code which are now after commented section *)
       rad50toa(_shell,((i << 8) + c)); (* Convert it to ascii *)

       (* If there's at least one zero in time (but not all !)
         (but date is not zero, i.e. user has been logged in at least once)
         then mark time as dubious with question mark: *)
       if(month && (!hours || !mins || !secs) && (hours || mins || secs))
        { c = '?'; }
       else { c = ' '; }

(* If one of the hours, mins or secs is lacking (i.e. zero), then
    the probability that it's hour is one of the 24 and for mins
    & secs it's one of 60. And witching hour (00:00 - 00:59) is
    normal hacking period for us.
   So if secs is zero, then move time bytes one step leftward,
    and if mins is zero too, then move two steps:
 *)
       if(!secs)
        { (* Move one step "leftward": *)
          secs = mins; mins = hours; hours = 0;
          (* If (orig.) minutes lacking too, then move one step more: *)
          if(!secs) { secs = mins; mins = 0; }
          (* Else if only one time-item lacking, and original first time-byte
             is over 23, then we can be sure that it's not hours, so mark
             time as undubious: *)
          else if(mins > 23) { c = ' '; }
        }

(*     clear_buf(_age,L_AGE); *)
       sprintf(_age,"%02u-%s-%02u %02u:%02u:%02u%c",
          day,getmonth(month),year,hours,mins,secs,c);

(*     clear_buf(_comment,L_COMMENT); *)
       sprintf(_comment,"%u",login_count);


                COMMENTED OUT SECTION ENDS HERE
========================================================================= */

       /* Read the Radix-50 word for CLI (MCR or DCL): */
       if((c = getc(_pw_file)) == EOF) { eof_ertzu(); }
       if((i = getc(_pw_file)) == EOF) { eof_ertzu(); }

/* Read surplu(s)-bytes from the end of the record, if there's any:
   (e.g. if slave-terminal)
 */
       while(1)
        {
          if((c = getc(_pw_file)) == EOF) { break; }
          /* If it's first octal digit of next UIC, then push it back
             to io stream and break from this loop: */
          if((c & ~7) == '0') { ungetc(c,_pw_file); break; }
        }

       cut_blankos(_name);
       cut_blankos(_passwd);
       cut_blankos(_gecos);

       strcat(_gecos," "); /* Append blanko after first name */
       strcat(_gecos,_name); /* Concatenate last name after that */
 
       return(&_p);

}

/* Commented out from abridged version:
static char *months[]=
 {
   "000", "JAN", "FEB", "MAR", "APR", "MAY", "JUN",
          "JUL", "AUG", "SEP", "OCT", "NOV", "DEC", NULL
 };


char *getmonth(_month_)
unsigned int _month_;
{
    if(_month_ <= 12) { return(months[_month_]); }
    else { return("???"); }
}
*/

/* Strip trailing blanks off from the string s: */
char *cut_blankos(s)
register char *s;
{
    register char *mark,*start;

    start = s;
    mark = NULL;

    while(*s)
     {
/* If white space and previous wasn't white space (or this is first char)
    then mark this character as possible cut point: */
       if(isspace(*s) && ((s == start) || !isspace(*(s-1))))
        { mark = s; }
       s++;
     }

    /* Cut the string after last non-space character: */
    if(mark) { *mark = '\0'; }

    return(start);
}

clear_buf(buffer,length)
register char *buffer;
register unsigned int length;
{
    while(length--) { *buffer++ = '\0'; }
}

int substitute(to,from,s)
register unsigned int to,from;
register char *s;
{
    register unsigned count;

    /* Clear the upper bytes if some stupid code has sign-extended them: */
    to   &= 0xFF;
    from &= 0xFF;

    count = 0;
    while(*s)
     {
       if(((unsigned int) *s) == from) { *s = to; count++; }
       s++;
     }

    return(count);
}


/* Converts every character of s with convfun, for example:
    convert_string(buf,toupper);
    changes every alphabetic character in buf to upper case.
 */
char *convert_string(s,convfun)
register char *s;
register PFI convfun;
{
        char *orig_s;

        orig_s = s;
        while(*s) { *s = ((*convfun)(*s)); s++; }
        return(orig_s);
}


eof_ertzu()
{
     ertzu("\n**%s: Premature EOF encountered, exiting !\n");
}

ertzu(errmsg)
char *errmsg;
{
     FILE *errfp;
     register unsigned int i;

          fprintf(stderr,errmsg,_progname);
          /* Open error output to console log: */
          if(!(errfp = fopen(ERRORFILE,"w")))
           {
             fprintf(stderr,"\n**%s: cannot open %s !\n",_progname,ERRORFILE);
             exit(1);
           }

          fprintf(errfp,errmsg,_progname);

          /* Dump the buffers. To some special file because it can contain
              pieces of passwords or something: */

          dumph(errfp,_p.pw_name);
          dumph(errfp,_p.pw_passwd);
          fprintf(errfp,"uid: %06o   gid: %06o\n",_p.pw_uid,_p.pw_gid);
          dumph(errfp,_p.pw_age);
          dumph(errfp,_p.pw_comment);
          dumph(errfp,_p.pw_gecos);
          dumph(errfp,_p.pw_dir);
          dumph(errfp,_p.pw_shell);

          for(i=0; i < L_BUF; i++)
           {
             fprintf(errfp,"%3u %06o: %c %03o %03u.\n",
                     i,i,(isprint(_buf[i]) ? _buf[i] : '.'),
                     ((unsigned int) _buf[i]),((unsigned int) _buf[i]));
           }

          exit(1);
}

dumph(fp,s)
FILE *fp;
char *s;
{
    fprintf(fp,"%s/%u.\n",s,strlen(s));
}


