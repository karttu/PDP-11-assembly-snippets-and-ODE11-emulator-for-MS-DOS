
#include "lb:[1,1]stdio.h"
#include "lb:[1,1]ctype.h"


FILE *myfopen();
char *strsave();
char *myfgets();

#define MAXCONFS 60

char *confnames[MAXCONFS+1];
unsigned int readsofars[MAXCONFS+1];

#define MAXBUF 79
char buf[MAXBUF+3];

main(argc,argv)
int argc;
char **argv;
{
    
}


/*
   This read Conference names and first unread message numbers
   from status file in user's home directory,
   to arrays confnames and readsofars.
   Returns as result the number of conferences.
 */
int readconfstats(statfile)
char *statfile;
{
    register unsigned int n;
    register FILE *fp;

    fp = myfopen(statfile,"r");

    n = 0;
    while(myfgets(buf+15,MAXBUF-15,fp))
     {
       sscanf(buf+15,"%s %o",buf,(readsofars+n));
       confnames[n] = strsave(buf);
       if(n++ == MAXCONFS) { break; } /* Too much conferences in file */
     }

    confnames[n] = NULL; /* End marker */

    return(n);
}


writeconfstats(statfile)
char *statfile;
{
    register FILE *fp;
    register unsigned int n;

/* First delete the old statusfile(s) */
    sprintf(buf,"PIP %s;*/DE",statfile);
    system(buf);

/* Then open new one:
   (This is little bit dangerous, as could not the new file be opened,
   then all the status information is lost!)
 */
    fp = myfopen(statfile,"w");

    n = 0;
    while(confnames[n])
     {
       fprintf(fp,"%s\t%o\n",confnames[n],readsofars[n]);
       n++;
     }
    fclose(fp);
    return(n);
}



int more(fp,lines_cnt)
register FILE *fp;
register unsigned int lines_cnt;
{
    while(lines_cnt--)
     {
       if(!fgets(buf,MAXBUF,fp)) { return(0); } /* Indicate EOF */
       fputs(buf,stdout);
     }

    return(1);
}

FILE *myfopen(filename,mode)
register char *filename,*mode;
{
    register FILE *fp;

    if(fp = fopen(filename,mode)) { return(fp); }
    else
     {
       fprintf(stderr,
"\n**%s: Cannot open file %s in mode %s !\n",filename,mode);
       exit(ERTZU);
     }
}


