

static int _splamax;

int dsplatch(s1,s2,diffs)
register char *s1,*s2;
register int diffs;
{
    int dsplatch();
    register int d1,d2,d3,m;

loop:

    /* If more differences than allowed: */
    if(diffs > _splamax)  return(diffs);
    if(!*s1 && !*s2) return(diffs); /* Both at the end */
    if(!*s1) { s2++; diffs++; goto loop; } /* s1 in the end */
    if(!*s2) { s1++; diffs++; goto loop; } /* s2 in the end */
    if(*s1 == *s2) { s1++; s2++; goto loop; } /* same chars */
    else
       {
         d1 = (dsplatch(s1+1,s2+1,diffs+1)); /* different chars */
         d2 = (dsplatch(s1+1,s2,diffs+1)); /* extra character in s1 */
         d3 = (dsplatch(s1,s2+1,diffs+1)); /* extra character in s2 */
         m = min(d1,d2); /* min is macro */
         return(min(m,d3));
       }
}


int splatch(s1,s2,overridemax)
char *s1,*s2;
/* If unzero, then used as a value for maximum differences allowed: */
int overridemax;
{
	int dsplatch();
	
	register int d,s1l; /* s1l = s1's length */

	d = ((s1l = strlen(s1)) - strlen(s2));
        if(overridemax) { _splamax = overridemax; }
	else 
	 { switch(s1l)
	       {
	         case 0: case 1: case 2:
		      _splamax = 0;
		      break;
		 case 3: case 4:
		      _splamax = 1;
		      break;
		 case 5: case 6: case 7: case 8:
		      _splamax = 2;
		      break;
		 default:
		      _splamax = 3;
		      break;
	       }
         }
	if(abs(d) > _splamax) return(FALSE);
	if(dsplatch(s1,s2,0) > _splamax) { return(FALSE); }
	else { return(TRUE); }

}

