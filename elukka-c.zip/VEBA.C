
#include "lb:[1,1]stdio.h"

main(argc,argv)
int argc;
char **argv;
{
    if(!*argv[1]) { exit(0); }
    printf("mystrlen(%s) = %u\n",argv[1],mystrlen(argv[1]));
}

int mystrlen(s)
register char *s;
{
    register char *x;

    x = s;
    while(*s++) { }

    return((s - x) - 1);
}



