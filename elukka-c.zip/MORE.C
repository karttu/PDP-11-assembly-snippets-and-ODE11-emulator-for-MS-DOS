#include "dl0:[1,1]stdio.h"

main(argc, argv)
int argc;
char *argv[];
{
	int n, lines, r,pros,scroll_size;
	char rivi[100];
	FILE *kala;
	long fsize,ftell(),last_seek;
	n = 99; r = 0; scroll_size = 11;
	last_seek=1;
	if (argc == 2) { 
		lines = 23;
	} else {
		lines = atoi(argv[2]);
	}

	if (!(kala=fopen(argv[1],"r"))) {
		perror(argv[1]);
		exit();
	}
	fseek(kala,0L,2);
	fsize=ftell(kala);
	fseek(kala,0L,0);
	while (!feof(kala)) {
		fgets(rivi, n, kala);
		fputs(rivi, stdout);
		r++;
		if (lines==r) {
			pros=(int)((ftell(kala)-fsize) / fsize * 100L);
			printf("\033[7mMORK-%s (%d%%)\033[0m",argv[1],
			pros);
			gets(rivi);
			switch(*rivi) {
				case 'q':
				case 'Q':
					goto uloos;
				case ' ':
					r = lines - 1;
					break;
				case '\n':
				case 'z':
					r=0;
					break;
				case '\'':
					if(last_seek != -1)
						fseek(kala,last_seek,0);
    					else
    						fputs("\007",stdout);
					break;
			}
		fputs("\033M\033[1M",stdout);
		}
	}
uloos:
fclose(kala);
}
