

/* USL.C -- USer Listing command by Antti Karttunen, 1-APR-1991,
    lists all users and their UIC's and login times, etc.

    This code is Public Domain.
 */

 
#include "lb:[1,1]stdio.h"
#include "lb:[1,1]pwd.h"

struct passwd *getpwent(),*getpwild();
char *rindex();
char *fgets();

#define BUFSIZ 3

main(argc,argv)
int argc;
char **argv;
{
    register struct passwd *p;
    char **a;
    register char *s,*pattern;
    register unsigned int user_count;
    unsigned int page_len,args;
    char buf[BUFSIZ+2];

    args = page_len = user_count = 0;

    while((a = (argv+--argc)) > argv)
     {
       s = *a;
       if(*s == '-') /* If option */
        {
          switch(tolower(*s+1))
           {
             default:
              { 
                if(isdigit(*s+1)) { page_len = atoi(s+1); break; }
                else { help(s); exit(1); }
              }
           }
        }
       else { args++; }
     }
 
    fprintf(stderr,
/* 234567890123456789012345678901234567890123456789012345678901234567890 */
"User                        Home directory  Last login          # of logins\n"
           );

    if(!args) { pattern = "*"; goto torttu; }

    while(pattern = *++argv)
     {
       if(*pattern == '-') { /* page_len = atoi(pattern+1); */ continue; }
torttu:
       while(p = getpwild(pattern))
        { /* Cut last name from the gecos: */
          user_count++;
          if(s = rindex(p->pw_gecos,' ')) { *s = '\0'; }
          printf("%-12s %-14s %s   %s %s\n",
                   p->pw_gecos,p->pw_name,p->pw_dir,
                   p->pw_age,p->pw_comment);
          if(page_len && !(user_count % page_len))
           {
             fprintf(stderr,"USL: More ?");
             fgets(buf,BUFSIZ,stdin);
             if((tolower(*buf) == 'q') || (tolower(*buf) == 'n'))
              { goto pogo; }
           }
        }
       endpwent();
     }

pogo:
    fprintf(stderr,"\n%u users.\n",user_count);
}


help(s)
char *s;
{
    fprintf(stderr,
"\nUSL: illegal option %s !\n",s);
    fprintf(stderr,
"usage: usl [-page_length] [pattern]\n");
/*
    fprintf(stderr,
"Examples:\n");
    fprintf(stderr,
"usl *        (same as usl without arguments) Show all users\n");
    fprintf(stderr,
"usl smith     Show user smith\n");
    fprintf(stderr,
"usl *nen      Show all users whose surname (i.e. user-id) ends with nen\n");
    fprintf(stderr,
"usl jussi_    Show all users whose first name is Jussi\n");
    fprintf(stderr,
"usl -20 302   Show all users from the group 302 and pause after every\n");
    fprintf(stderr,
"              twenty lines.\n");
    fprintf(stderr,
"usl [201,201] Show who is user with UIC [201,201] (usl 201,201 works also)\n");
    fprintf(stderr,
"usl .         Show your UIC.\n");
 */
}

