 
main()
{
     long time();
     char *ctime();
     long aika;

     while(1)
      {
        time(&aika);
        printf("%lu\t%s",aika,ctime(&aika));
      }
}

